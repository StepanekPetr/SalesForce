﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentAssertions;
using OpenQA.Selenium;
using SalesForce.Pages;
using TechTalk.SpecFlow;

namespace SalesForce.Steps
{
    [Binding]
    class SingUpSteps
    {
        public static SingUpPage singUpPage;
        public static TempMailPage tempMailPage;
        public static ChangePasswordPage changePasswordPage;
        public static BrowserChromeAdapter WebDriverAdapter;
        public static HomePage homePage;

        string userMail;
        private string userPass = "Password123";

        [BeforeTestRun]
        public static void InitializePages()
        {
             WebDriverAdapter = new BrowserChromeAdapter();
             singUpPage = new SingUpPage(WebDriverAdapter.driver);
             tempMailPage = new TempMailPage(WebDriverAdapter.driver);
             changePasswordPage = new ChangePasswordPage(WebDriverAdapter.driver);
             homePage = new HomePage(WebDriverAdapter.driver);
        }

        [AfterTestRun]
        public static void cleanUp()
        {
            WebDriverAdapter.driver.Dispose();
        }

        [Given(@"I have temporary email address")]
        public void GivenIHaveTemporaryEmailAddress()
        {
            tempMailPage.NavigateToPage();
            userMail = tempMailPage.ObtainNewMail();
        }


        [Given(@"I register for a Salesforce Developer account")]
        public void GivenIRegisterForASalesforceDeveloperAccount()
        {
            singUpPage.NavigateToPage();
            singUpPage.TypeFirstName("test");
            singUpPage.TypeLastName("test");
            singUpPage.TypeEmailAdress(userMail);
            singUpPage.SetRole("Administrator");
            singUpPage.TypeCompany("test1");
            singUpPage.SetCountry("Cyprus");
            singUpPage.TypePostalCode("test1");
            singUpPage.TypeUsername(userMail);
            singUpPage.ClickEULAcheckbox();
            singUpPage.ClickSingUpButton();
        }

        [When(@"I confirm my account email")]
        public void WhenIConfirmMyAccountEmail()
        {
            singUpPage.WaitForAlmostThere();
            tempMailPage.NavigateToPage();
            tempMailPage.SetMailbox(userMail);
            tempMailPage.OpenFirstMail();
            tempMailPage.FindAndClickVerify();
        }

        [When(@"I complete the registration process by setting a password")]
        public void WhenICompleteTheRegistrationProcessBySettingAPassword()
        {
            changePasswordPage.WaitForPageLoad();
            changePasswordPage.TypeNewPass(userPass);
            changePasswordPage.ConfirmNewPass(userPass);
            changePasswordPage.TypeSecurityAnswer("Atlantida");
            changePasswordPage.ClickChangePassword();
        }

        [Then(@"I should be on the Salesforce Developer instance homepage")]
        public void ThenIShouldBeOnTheSalesforceDeveloperInstanceHomepage()
        {
            homePage.IsHomepageDislayed();
        }


    }
}
