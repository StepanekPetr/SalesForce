﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using SalesForce.Interfaces;

namespace SalesForce
{
    class BrowserChromeAdapter : IBrowser
    {
        readonly TimeSpan waitTime = TimeSpan.FromSeconds(30);
        public ChromeDriver driver { get; }

        public BrowserChromeAdapter()
        {
            driver = new ChromeDriver();
            driver.Manage().Timeouts().ImplicitlyWait(waitTime);
            driver.Manage().Window.Maximize();
        }

    }
}
