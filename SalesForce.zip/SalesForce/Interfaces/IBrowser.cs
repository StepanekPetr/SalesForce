﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium.Remote;

namespace SalesForce.Interfaces
{
    class IBrowser
    {
        public RemoteWebDriver driver { get; }
    }
}
