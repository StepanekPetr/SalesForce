﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentAssertions;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;

namespace SalesForce.Pages
{
    class ChangePasswordPage
    {
        private RemoteWebDriver driver;

        IWebElement Logo => driver.FindElement(By.Id("logo"));
        IWebElement NewPasswordInput => driver.FindElement(By.Id("newpassword"));
        IWebElement ConfirmPasswordInput => driver.FindElement(By.Id("confirmpassword"));
        IWebElement SecurityAnswerInput => driver.FindElement(By.Id("answer"));
        IWebElement ConfirmButton => driver.FindElement(By.Id("password-button"));

        

        public ChangePasswordPage(RemoteWebDriver driver)
        {
            this.driver = driver;
        }

        public void WaitForPageLoad()
        {
            Logo.Displayed.Should().BeTrue();
        }

        public void TypeNewPass(string value)
        {
            NewPasswordInput.SendKeys(value);
        }

        public void ConfirmNewPass(string value)
        {
            ConfirmPasswordInput.SendKeys(value);
        }

        internal void TypeSecurityAnswer(string value)
        {
            SecurityAnswerInput.SendKeys(value);
        }

        public void ClickChangePassword()
        {
            ConfirmButton.Click();
        }
    }
}
