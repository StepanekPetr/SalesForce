﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentAssertions;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;

namespace SalesForce.Pages
{
    class HomePage
    {
        private RemoteWebDriver driver;

        private IWebElement TopHeader => driver.FindElement(By.Id("oneHeader"));
        private IWebElement BranBand => driver.FindElement(By.Id("brandBand_1"));

        public HomePage(RemoteWebDriver driver)
        {
            this.driver = driver;
        }

        public void IsHomepageDislayed()
        {
            TopHeader.Displayed.Should().BeTrue();
            BranBand.Displayed.Should().BeTrue();
        }
    }
}
