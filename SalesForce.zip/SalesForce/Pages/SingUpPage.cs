﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FluentAssertions;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;

namespace SalesForce.Pages
{
    class SingUpPage
    {
        private RemoteWebDriver driver;
        private string url = "https://developer.salesforce.com/signup";


        IWebElement FirstNameInput => driver.FindElement(By.Id("first_name"));
        IWebElement LastNameInput => driver.FindElement(By.Id("last_name"));
        IWebElement EmailAdressInput => driver.FindElement(By.Id("email"));
        IWebElement RoleDropDown => driver.FindElement(By.Id("job_role"));
        IWebElement CompanyInput => driver.FindElement(By.Id("company"));
        IWebElement CountryDropDown => driver.FindElement(By.Id("country"));
        IWebElement PostalCodeInput => driver.FindElement(By.Id("postal_code"));
        IWebElement UserNameInput => driver.FindElement(By.Id("username"));
        IWebElement EulaCheckbox => driver.FindElement(By.Id("eula"));
        IWebElement SingMeUpButton => driver.FindElement(By.Id("submit_btn"));
        IWebElement LogoImage => driver.FindElement(By.ClassName("logo_img"));

        public void NavigateToPage ()
        {
            driver.Navigate().GoToUrl(url);
        }
        public SingUpPage(RemoteWebDriver driver)
        {
            
            this.driver = driver;
        }

        public void TypeFirstName(string value)
        {
            FirstNameInput.SendKeys(value);
        }

        public void TypeLastName(string value)
        {
            LastNameInput.SendKeys(value);
        }

        public void TypeEmailAdress(string value)
        {
            EmailAdressInput.SendKeys(value);
        }

        public void SetRole(string role)
        {
            ReadOnlyCollection<IWebElement> list = RoleDropDown.FindElements(By.TagName("option"));

            foreach (var option in list)
            {
                if (option.Text.ToLower().Equals(role.ToLower()))
                {
                    option.Click();
                    return;
                }
            }
        }

        public void TypeCompany(string value)
        {
            CompanyInput.SendKeys(value);
        }

        public void SetCountry(string country)
        {
            ReadOnlyCollection<IWebElement> list = CountryDropDown.FindElements(By.TagName("option"));

            foreach (var option in list)
            {
                if (option.Text.ToLower().Equals(country.ToLower()))
                {
                    option.Click();
                    return;
                }
            }
        } 


        public void TypePostalCode(string value)
        {
            PostalCodeInput.SendKeys(value);
        }

        public void TypeUsername(string value)
        {
            UserNameInput.SendKeys(value);
        }

        public void ClickEULAcheckbox()
        {
            EulaCheckbox.Click();
        }

        public void ClickSingUpButton()
        {
            SingMeUpButton.Click();
        }

        public void WaitForAlmostThere()
        {
            LogoImage.Displayed.Should().BeTrue();
        }
    }
}