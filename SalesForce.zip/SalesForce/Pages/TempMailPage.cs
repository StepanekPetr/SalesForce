﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;

namespace SalesForce.Pages
{
    class TempMailPage
    {
        private RemoteWebDriver driver;
        private string url = "https://www.guerrillamail.com/inbox";
        private string userEmail;
        private IWebElement ScrambleAddressCheckbox => driver.FindElement(By.Id("use-alias"));
        private IWebElement MailAdress => driver.FindElement(By.Id("email-widget"));

        private IWebElement MailAdressPrefix => driver.FindElement(By.Id("inbox-id"));
        private IWebElement SetButton => driver.FindElement(By.ClassName("save button small"));
        private IWebElement EmaiList => driver.FindElement(By.Id("email_list"));
        private IWebElement Email => driver.FindElement(By.ClassName("email"));
        private IWebElement VerifyAccountHref => driver.FindElement(By.XPath("//div[. = 'Verify Account']"));



        public void NavigateToPage()
        {
            driver.Navigate().GoToUrl(url);
        }
        public TempMailPage(RemoteWebDriver driver)
        {
            this.driver = driver;
        }

        public string ObtainNewMail()
        {
            if (ScrambleAddressCheckbox.Selected)
                ScrambleAddressCheckbox.Click();
            userEmail = MailAdress.Text;
            return userEmail;
        }

        public void SetMailbox(string value)
        {
            MailAdressPrefix.Click();
            MailAdressPrefix.FindElement(By.TagName("input")).SendKeys(value.Split('@')[0]);
            MailAdressPrefix.FindElements(By.TagName("button"))[0].Click();
        }


        public void OpenFirstMail()
        {
            while (EmaiList.FindElements(By.TagName("tr")).Count !=2);
            {
                Thread.Sleep(500);//waiting for incoming mail
            }
            EmaiList.FindElements(By.TagName("tr"))[0].Click();
        }

        public void FindAndClickVerify()
        {
            var linksInMail = Email.FindElements(By.TagName("a"));
            var link = linksInMail[0].GetAttribute("href");
            driver.Navigate().GoToUrl(link);
        }
    }
}
